ScriptRunner - an electron app for running saved scripts from the menu bar

BUILD:
    npm run build:mac   (For macOs)
    npm run build:win   (For Win)
    npm run build:linux (For Linux)
    npm run build       (For all)

Settings:
    The Settings menu item opens the settings file.. It should be of the following format..
    
    {
        "scripts": [
            // add one object (like below) per script 
            {
                // used in menu item as `Run <label>`
                "label": "myScript",

                // absolute path of the executable
                "file": "path/to/script>",
                
                // (optional) timeout in ms (default is 1000)
                "timeout": 5000
            }
        ]
    }
    

Common Errors:
    `Permission Denied`: The script files provided need to be executable.. (chmod +x <script.sh>)
    `File not found`: The script file wasn't found on the path given.. (Check spelling)
